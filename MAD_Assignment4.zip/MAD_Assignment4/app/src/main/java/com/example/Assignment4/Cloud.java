package com.example.Assignment4;
public class Cloud {
    private Integer a;
    public Cloud() {
    }
    public Cloud(Integer a) {
        super();
        this.a = a;
    }
    public Integer getA() {
        return a;
    }

    public void setA(Integer a) {
        this.a = a;
    }
}
